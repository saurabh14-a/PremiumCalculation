const additionalFieldsContainer = document.getElementById('additionalFields');
const coverageFieldsMap = new Map();

document.getElementById('personDetails').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const userDetails = Object.fromEntries(new FormData(e.target));
    const territoryCode = userDetails.territoryCode;
    const territoryCodeRegex = /^[0-9]{5,6}$/; // Matches 5 or 6-digit numeric values
    
    if (!territoryCodeRegex.test(territoryCode)) {
        alert("Please enter a valid 5 or 6-digit ZIP/Pin Code.");
        return;
    }
    localStorage.setItem('userDetails', JSON.stringify(userDetails));

    const coverageData = await fetchCoverages({ occupation: userDetails.occupation });
    displayCoverageOptions(coverageData);
});

async function fetchCoverages(query) {
    try {
        const response = await fetch("http://localhost:5000/api/getCoverage", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(query),
        });
        return response.ok ? response.json() : [];
    } catch (error) {
        console.error("Error fetching coverages:", error);
        return [];
    }
}

function displayCoverageOptions(coverageData) {
    const coverageList = document.getElementById('coverageList');
    coverageList.innerHTML = coverageData.map(item => `
        <div>
            <input type="checkbox" value="${item.title}" data-description="${item.description}" />
            <label title="${item.description}">${item.title}</label>
        </div>
    `).join('');
    document.getElementById('coverageSection').classList.remove('hidden');
}

document.getElementById("coverageList").addEventListener("change", async (e) => {
    const selectedCoverage = e.target.value;
    if (e.target.checked) {
        const fields = await fetchAdditionalFields(selectedCoverage);
        coverageFieldsMap.set(selectedCoverage, fields);
    } else {
        coverageFieldsMap.delete(selectedCoverage);
    }
    renderAllAdditionalFields();
});

async function fetchAdditionalFields(coverage) {
    try {
        const response = await fetch("http://localhost:5000/api/getAdditionalFields", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ coverage }),
        });
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const text = await response.text(); // Fetch text from the response
        const trimmedText = text.trim(); // Trim whitespace
        return JSON.parse(trimmedText);
    } catch (error) {
        console.error("Error fetching additional fields:", error);
        return [];
    }
}

function renderAllAdditionalFields() {
    const allFields = Array.from(coverageFieldsMap.values()).flat();
    const uniqueFields = Array.from(new Set(allFields.map(field => field.id)))
        .map(id => allFields.find(field => field.id === id));

    additionalFieldsContainer.innerHTML = uniqueFields.map(field => `
        <label for="${field.id}">${field.label}</label>
        <input type="${field.type}" id="${field.id}" name="${field.id}" ${field.required ? 'required' : ''} />
    `).join('');

    additionalFieldsContainer.classList.toggle('hidden', uniqueFields.length === 0);
}

document.getElementById("calculatePremium").addEventListener("click", async () => {
    const selectedCoverages = Array.from(
        document.querySelectorAll("#coverageList input[type='checkbox']:checked")
    ).map(checkbox => checkbox.value);

    const additionalData = {};
    const inputs = additionalFieldsContainer.querySelectorAll("input, select");
    inputs.forEach(input => {
        additionalData[input.name] = input.value;
    });

    const userDetails = JSON.parse(localStorage.getItem("userDetails"));
    if (!userDetails || selectedCoverages.length === 0) {
        alert("Please provide user details and select at least one coverage.");
        return;
    }

    try {
        const response = await fetch("http://localhost:5000/api/calculatePremium", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ userDetails, selectedCoverages, additionalData }),
        });
        const premiumData = await response.json();
        displayPremium(premiumData);
    } catch (error) {
        console.error("Error calculating premium:", error);
    }
});

function displayPremium(premiumData) {
    const premiumSection = document.getElementById("premiumSection");
    const premiumDetails = document.getElementById("premiumDetails");

    // Clear previous data
    premiumDetails.innerHTML = "";

    // Check if premiumData is an object and render it properly
    if (typeof premiumData === "object" && premiumData !== null) {
        for (const [key, value] of Object.entries(premiumData)) {
            const premiumInfo = document.createElement("p");
            premiumInfo.textContent = `${key}: ${value}`;
            premiumDetails.appendChild(premiumInfo);
        }
    } else {
        // If premiumData is not an object, render it as-is
        premiumDetails.textContent = premiumData;
    }

    // Make the premium section visible
    premiumSection.classList.remove("hidden");
}

