const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const app = express();
const cors = require('cors');

app.use(bodyParser.json());
app.use(cors());

const OPENAI_API_KEY = "your-openai-api-key";

async function fetchFromOpenAI(prompt) {
    try {
        const response = await axios.post("https://api.openai.com/v1/chat/completions", {
            model: "gpt-3.5-turbo",
            messages: [{ role: "user", content: prompt }],
            max_tokens: 300,
        }, {
            headers: { Authorization: `Bearer ${OPENAI_API_KEY}` },
        });
        const rawText = response.data.choices[0].message.content;
        const pareseText = rawText.replace(/```json|```/g, "").trim();
        return pareseText;
    } catch (error) {
        console.error("Error calling OpenAI API:", error.response?.data || error.message);
        throw new Error("Failed to fetch data from OpenAI.");
    }
}

app.post('/api/getCoverage', async (req, res) => {
    const { occupation } = req.body;
    const prompt = `Suggest insurance coverages for a person with occupation ${occupation}.`;
    const content = await fetchFromOpenAI(prompt);
    res.json(parseCoverageList(content));
});

app.post('/api/getAdditionalFields', async (req, res) => {
    const { coverage } = req.body;
    const prompt = `For ${coverage} insurance, list additional fields in JSON format with id, label, type, and required.`;
    const content = await fetchFromOpenAI(prompt);
    res.json(JSON.parse(content.trim()));
});

app.post('/api/calculatePremium', async (req, res) => {
    const { userDetails, selectedCoverages, additionalData } = req.body;
    const prompt = `You are an expert in calculating insurance premiums. Based on following; 
        User details: ${JSON.stringify(userDetails)}
        Coverages: ${JSON.stringify(selectedCoverages)}
        Additional Data: ${JSON.stringify(additionalData)}
        . Use industry standard formulas to calculate the premium. Just return the montly , quarterly and yearly premium in json format.
    `;
    const content = await fetchFromOpenAI(prompt);
    console.log(content)
    res.json({ premium: content });
});

function parseCoverageList(content) {
    return content.split('\n').filter(line => line).map(line => {
        const [title, description] = line.split(":").map(part => part.trim());
        return { title, description };
    });
}

const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
