// Buttons and Sections
const personBtn = document.getElementById('personBtn');
const companyBtn = document.getElementById('companyBtn');
const personForm = document.getElementById('personForm');
const companyForm = document.getElementById('companyForm');
const coverageSection = document.getElementById('coverageSection');
const premiumSection = document.getElementById('premiumSection');

// Show Forms
personBtn.addEventListener('click', () => {
  personForm.classList.remove('hidden');
  companyForm.classList.add('hidden');
});

companyBtn.addEventListener('click', () => {
  companyForm.classList.remove('hidden');
  personForm.classList.add('hidden');
});

// Submit Handlers
document.getElementById('personDetails').addEventListener('submit', async (e) => {
  e.preventDefault();
  const formData = new FormData(e.target);
  const userDetails = Object.fromEntries(formData);
  const coverageData = await fetchCoverage(userDetails);
  displayCoverageOptions(coverageData);
});

document.getElementById('companyDetails').addEventListener('submit', async (e) => {
  e.preventDefault();
  const formData = new FormData(e.target);
  const companyDetails = Object.fromEntries(formData);
  const coverageData = await fetchCoverage(companyDetails);
  displayCoverageOptions(coverageData);
});

// Fetch Coverage
async function fetchCoverage(details) {
  const response = await fetch('http://localhost:5000/api/getCoverage', { // Updated URL
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(details),
  });
  return response.json();
}

// Display Coverage Options
function displayCoverageOptions(coverageData) {
  const coverageList = document.getElementById('coverageList');
  coverageList.innerHTML = coverageData.map((item) => {
      // Use the `title` attribute for the tooltip
      return `<div>
          <input type="checkbox" value="${item.title}" />
          <label title="${item.description}">${item.title}</label>
      </div>`;
  }).join('');
  coverageSection.classList.remove('hidden');
}

// Calculate Premium
document.getElementById('calculatePremium').addEventListener('click', async () => {
  const selectedCoverages = Array.from(
      document.querySelectorAll('#coverageList input:checked')
  ).map((checkbox) => checkbox.value);

  const premiumData = await fetch('http://localhost:5000/api/calculatePremium', { // Updated URL
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ coverages: selectedCoverages }),
  });

  const premium = await premiumData.json();
  displayPremium(premium);
});

// Display Premium
function displayPremium(premiumData) {
  const premiumDetails = document.getElementById('premiumDetails');
  premiumDetails.innerHTML = `
    <p>Monthly: ${premiumData.monthly}</p>
    <p>Quarterly: ${premiumData.quarterly}</p>
    <p>Yearly: ${premiumData.yearly}</p>
  `;
  premiumSection.classList.remove('hidden');
}