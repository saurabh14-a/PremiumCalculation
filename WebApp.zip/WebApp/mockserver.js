const express = require('express');
const app = express();

app.use(express.json());

app.post('/v1/chat/completions', (req, res) => {
    const response = {
        "choices": [
            {
                "message": {
                    "content": "Here are some example insurance coverages: Health Insurance, Liability Insurance, and Property Insurance."
                }
            }
        ]
    };
    res.json(response);
});

const PORT = 5001;
app.listen(PORT, () => console.log(`Mock server running on http://localhost:${PORT}`));
