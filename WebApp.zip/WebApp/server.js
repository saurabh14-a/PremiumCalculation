const express = require('express');
const cors = require('cors');
const axios = require('axios');


const app = express();
app.use(cors());
app.use(express.json());

const OPENAI_API_KEY ='';

// Helper function to call OpenAI API
async function fetchCoveragesFromOpenAI(prompt) {
    try {
        const response = await axios.post(
            'https://api.openai.com/v1/chat/completions',
            {
                model: "gpt-3.5-turbo",
                messages: [
                    { role: "system", content: "You are an expert in insurance coverage suggestions." },
                    { role: "user", content: prompt }
                ],
                max_tokens: 300,
                temperature: 0.7,
            },
            {
                headers: {
                    'Authorization': `Bearer ${OPENAI_API_KEY}`,
                    'Content-Type': 'application/json',
                },
            }
        );

        const content = response.data?.choices?.[0]?.message?.content;
        if (content) {
            // Extract each coverage title
            const coverages = content
                .split('\n') // Split by new lines
                .map(line => line.match(/\*\*(.*?)\*\*/)?.[1]) // Extract text inside "** **"
                .filter(Boolean); // Remove undefined or null values
            return coverages;
        } else {
            throw new Error("Unexpected API response structure");
        }
    } catch (error) {
        console.error("Error calling OpenAI API:", error.response?.data || error.message);
        return [];
    }
}

// API to return coverage data
app.post('/api/getCoverage', async (req, res) => {
    const { name, occupation, industry } = req.body;
    let prompt;

    if (occupation) {
        // For individuals
        prompt = `Suggest appropriate insurance coverages for a person working as ${occupation}.`;
    } else if (industry) {
        // For companies
        prompt = `Suggest appropriate insurance coverages for a company in the ${industry} industry.`;
    } else {
        return res.status(400).json({ error: 'Invalid input. Please provide occupation or industry.' });
    }

    const coverages = await fetchCoveragesFromOpenAI(prompt);
    res.json(coverages);
});

// Helper function to call OpenAI API
async function fetchCoveragesFromOpenAI(prompt) {
    try {
        const response = await axios.post(
            'https://api.openai.com/v1/chat/completions',
            {
                model: "gpt-3.5-turbo",
                messages: [
                    { role: "system", content: "You are an expert in insurance coverage suggestions." },
                    { role: "user", content: prompt }
                ],
                max_tokens: 300,
                temperature: 0.7,
            },
            {
                headers: {
                    'Authorization': `Bearer ${OPENAI_API_KEY}`,
                    'Content-Type': 'application/json',
                },
            }
        );

        const content = response.data?.choices?.[0]?.message?.content;
        if (content) {
            const coverages = [];

            // Split content into lines and extract title and description
            const lines = content.split('\n');
            for (const line of lines) {
                const match = line.match(/\*\*(.*?)\*\*/); // Match text inside "** **"
                if (match) {
                    const title = match[1].trim();
                    const description = line.split(':')[1]?.trim() || ''; // Extract text after the colon
                    coverages.push({ title, description });
                }
            }
            return coverages;
        } else {
            throw new Error("Unexpected API response structure");
        }
    } catch (error) {
        console.error("Error calling OpenAI API:", error.response?.data || error.message);
        return [];
    }
}


// API to calculate premium dynamically using OpenAI
app.post('/api/calculatePremium', async (req, res) => {
    const { userDetails, coverages } = req.body;

    // Generate a detailed prompt
    const prompt = `
    Calculate a premium amount for the following user data:
    User Details:
    ${Object.entries(userDetails)
        .map(([key, value]) => `${key}: ${value}`)
        .join('\n')}

    Selected Coverages:
    ${coverages.join(', ')}

    Consider the user type (person or company), age, annual income (if applicable), or yearly revenue (for a company), and adjust the premium amount based on selected coverages and risk factors. Provide a breakdown of monthly, quarterly, and yearly premiums.
    `;

    // Fetch premium from OpenAI
    const premiumResponse = await fetchPremiumFromOpenAI(prompt);

    // Parse the response from OpenAI (if structured)
    const parsedPremium = parsePremiumResponse(premiumResponse);

    res.json(parsedPremium || { error: "Failed to calculate premium." });
});

// Helper function to parse the OpenAI response
function parsePremiumResponse(response) {
    const lines = response.split('\n').map((line) => line.trim());
    const premiumData = {
        monthly: null,
        quarterly: null,
        yearly: null,
    };

    lines.forEach((line) => {
        if (line.toLowerCase().includes('monthly')) {
            premiumData.monthly = line.split(':')[1]?.trim();
        } else if (line.toLowerCase().includes('quarterly')) {
            premiumData.quarterly = line.split(':')[1]?.trim();
        } else if (line.toLowerCase().includes('yearly')) {
            premiumData.yearly = line.split(':')[1]?.trim();
        }
    });

    return premiumData;
}

// Start server
const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
