const express = require('express');
const cors = require('cors');
const axios = require('axios');


const app = express();
app.use(cors());
app.use(express.json());

const OPENAI_API_KEY = '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';

// Helper function to call OpenAI API
async function fetchCoveragesFromOpenAI(prompt) {
    try {
        const response = await axios.post(
            'https://api.openai.com/v1/chat/completions', // OpenAI Endpoint
            {
                model: "gpt-4o-mini",
                messages: [
                    { role: "system", content: "You are an expert in insurance coverage suggestions." },
                    { role: "user", content: prompt }
                ],
                max_tokens: 200,
                temperature: 0.7,
            },
            {
                headers: {
                    'Authorization': `Bearer ${OPENAI_API_KEY}`,
                    'Content-Type': 'application/json',
                },
            }
        );

        const content = response.data?.choices?.[0]?.message?.content;
        if (content) {
            // Extract coverages by splitting and formatting
            const coverages = content
                .replace(/.*?:/, '') // Remove any introductory text before colon
                .split(',')          // Split by commas
                .map(item => item.trim()); // Trim whitespace
            return coverages; // Return an array of coverages
        } else {
            throw new Error("Unexpected API response structure");
        }
    } catch (error) {
        console.error("Error calling OpenAI API:", error.response?.data || error.message);
        return [];
    }
}


// API to return coverage data
app.post('/api/getCoverage', async (req, res) => {
    const { name, occupation, industry } = req.body;
    let prompt;

    if (occupation) {
        // For individuals
        prompt = `Suggest appropriate insurance coverages for a person working as ${occupation}.`;
    } else if (industry) {
        // For companies
        prompt = `Suggest appropriate insurance coverages for a company in the ${industry} industry.`;
    } else {
        return res.status(400).json({ error: 'Invalid input. Please provide occupation or industry.' });
    }

    const coverages = await fetchCoveragesFromOpenAI(prompt);
    res.json(coverages);
});

// Helper function to call OpenAI API
async function fetchPremiumFromOpenAI(prompt) {
    try {
        const response = await axios.post(
            'https://api.openai.com/v1/chat/completions',
            {
                model: "gpt-4o-mini",
                prompt,
                max_tokens: 150,
                temperature: 0.7,
            },
            {
                headers: {
                    'Authorization': `Bearer ${OPENAI_API_KEY}`,
                    'Content-Type': 'application/json',
                },
            }
        );
        return response.data.choices[0].text.trim();
    } catch (error) {
        console.error("Error calling OpenAI API:", error);
        return "Error calculating premium. Please try again later.";
    }
}

// API to calculate premium dynamically using OpenAI
app.post('/api/calculatePremium', async (req, res) => {
    const { userDetails, coverages } = req.body;

    // Generate a detailed prompt
    const prompt = `
    Calculate a premium amount for the following user data:
    User Details:
    ${Object.entries(userDetails)
        .map(([key, value]) => `${key}: ${value}`)
        .join('\n')}

    Selected Coverages:
    ${coverages.join(', ')}

    Consider the user type (person or company), age, annual income (if applicable), or yearly revenue (for a company), and adjust the premium amount based on selected coverages and risk factors. Provide a breakdown of monthly, quarterly, and yearly premiums.
    `;

    // Fetch premium from OpenAI
    const premiumResponse = await fetchPremiumFromOpenAI(prompt);

    // Parse the response from OpenAI (if structured)
    const parsedPremium = parsePremiumResponse(premiumResponse);

    res.json(parsedPremium || { error: "Failed to calculate premium." });
});

// Helper function to parse the OpenAI response
function parsePremiumResponse(response) {
    const lines = response.split('\n').map((line) => line.trim());
    const premiumData = {
        monthly: null,
        quarterly: null,
        yearly: null,
    };

    lines.forEach((line) => {
        if (line.toLowerCase().includes('monthly')) {
            premiumData.monthly = line.split(':')[1]?.trim();
        } else if (line.toLowerCase().includes('quarterly')) {
            premiumData.quarterly = line.split(':')[1]?.trim();
        } else if (line.toLowerCase().includes('yearly')) {
            premiumData.yearly = line.split(':')[1]?.trim();
        }
    });

    return premiumData;
}

// Start server
const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
