const express = require('express');
const cors = require('cors');
const axios = require('axios');


const app = express();
app.use(cors());
app.use(express.json());

const OPENAI_API_KEY = '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';

// Helper function to call OpenAI API
async function fetchCoveragesFromOpenAI(prompt) {
    try {
        const response = await axios.post(
            'http://localhost:5001/v1/chat/completions',
            {
                model: "gpt-3.5-turbo",
                messages: [
                    { role: "system", content: "You are an expert in insurance coverage suggestions." },
                    { role: "user", content: prompt }
                ],
                max_tokens: 200,
                temperature: 0.7,
            },
            {
                headers: {
                    'Authorization': `Bearer ${OPENAI_API_KEY}`,
                    'Content-Type': 'application/json',
                },
            }
        );
        return response.data.choices[0].text.trim().split('\n');
    } catch (error) {
        console.error("Error calling OpenAI API:", error);
        return ["Error fetching coverages. Please try again later."];
    }
}

// API to return coverage data
app.post('/api/getCoverage', async (req, res) => {
    const { name, occupation, industry } = req.body;
    let prompt;

    if (occupation) {
        // For individuals
        prompt = `Suggest appropriate insurance coverages for a person working as ${occupation}.`;
    } else if (industry) {
        // For companies
        prompt = `Suggest appropriate insurance coverages for a company in the ${industry} industry.`;
    } else {
        return res.status(400).json({ error: 'Invalid input. Please provide occupation or industry.' });
    }

    const coverages = await fetchCoveragesFromOpenAI(prompt);
    res.json(coverages);
});

// Helper function to call OpenAI API
async function fetchPremiumFromOpenAI(prompt) {
    try {
        const response = await axios.post(
            'https://api.openai.com/v1/chat/completions',
            {
                model: "gpt-3.5-turbo",
                prompt,
                max_tokens: 150,
                temperature: 0.7,
            },
            {
                headers: {
                    'Authorization': `Bearer ${OPENAI_API_KEY}`,
                    'Content-Type': 'application/json',
                },
            }
        );
        return response.data.choices[0].text.trim();
    } catch (error) {
        console.error("Error calling OpenAI API:", error);
        return "Error calculating premium. Please try again later.";
    }
}

// API to calculate premium dynamically using OpenAI
app.post('/api/calculatePremium', async (req, res) => {
    const { userDetails, coverages } = req.body;

    // Generate a detailed prompt
    const prompt = `
    Calculate a premium amount for the following user data:
    User Details:
    ${Object.entries(userDetails)
        .map(([key, value]) => `${key}: ${value}`)
        .join('\n')}

    Selected Coverages:
    ${coverages.join(', ')}

    Consider the user type (person or company), age, annual income (if applicable), or yearly revenue (for a company), and adjust the premium amount based on selected coverages and risk factors. Provide a breakdown of monthly, quarterly, and yearly premiums.
    `;

    // Fetch premium from OpenAI
    const premiumResponse = await fetchPremiumFromOpenAI(prompt);

    // Parse the response from OpenAI (if structured)
    const parsedPremium = parsePremiumResponse(premiumResponse);

    res.json(parsedPremium || { error: "Failed to calculate premium." });
});

// Helper function to parse the OpenAI response
function parsePremiumResponse(response) {
    const lines = response.split('\n').map((line) => line.trim());
    const premiumData = {
        monthly: null,
        quarterly: null,
        yearly: null,
    };

    lines.forEach((line) => {
        if (line.toLowerCase().includes('monthly')) {
            premiumData.monthly = line.split(':')[1]?.trim();
        } else if (line.toLowerCase().includes('quarterly')) {
            premiumData.quarterly = line.split(':')[1]?.trim();
        } else if (line.toLowerCase().includes('yearly')) {
            premiumData.yearly = line.split(':')[1]?.trim();
        }
    });

    return premiumData;
}

// Start server
const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
