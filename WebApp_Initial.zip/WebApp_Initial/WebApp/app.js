// Buttons and Sections
const personBtn = document.getElementById('personBtn');
const companyBtn = document.getElementById('companyBtn');
const personForm = document.getElementById('personForm');
const companyForm = document.getElementById('companyForm');
const coverageSection = document.getElementById('coverageSection');
const premiumSection = document.getElementById('premiumSection');

// Show Forms
personBtn.addEventListener('click', () => {
    personForm.classList.remove('hidden');
    companyForm.classList.add('hidden');
});

companyBtn.addEventListener('click', () => {
    companyForm.classList.remove('hidden');
    personForm.classList.add('hidden');
});

// Submit Handlers
document.getElementById('personDetails').addEventListener('submit', async (e) => {
    e.preventDefault();
    const userDetails = Object.fromEntries(new FormData(e.target));
    localStorage.setItem('userDetails', JSON.stringify(userDetails));
    const coverageData = await fetchCoverages({ occupation: userDetails.occupation });
    displayCoverageOptions(coverageData);
});

document.getElementById('companyDetails').addEventListener('submit', async (e) => {
    e.preventDefault();
    const companyDetails = Object.fromEntries(new FormData(e.target));
    localStorage.setItem('userDetails', JSON.stringify(companyDetails));
    const coverageData = await fetchCoverages({ industry: companyDetails.industry });
    displayCoverageOptions(coverageData);
});

// Fetch Coverage Options
async function fetchCoverages(query) {
    const response = await fetch("http://localhost:5000/api/getCoverage", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(query),
    });
    return response.json();
}

// Display Coverage Options
function displayCoverageOptions(coverageData) {
    const coverageList = document.getElementById('coverageList');
    coverageList.innerHTML = coverageData.map(item => `
        <div>
            <input type="checkbox" value="${item.title}" />
            <label title="${item.description}">${item.title}</label>
        </div>
    `).join('');
    coverageSection.classList.remove('hidden');
}

// Calculate Premium
document.getElementById("calculatePremium").addEventListener("click", async () => {
    const userDetails = JSON.parse(localStorage.getItem('userDetails'));
    const selectedCoverages = Array.from(
        document.querySelectorAll("#coverageList input[type='checkbox']:checked")
    ).map(cb => cb.value);

    if (!userDetails || selectedCoverages.length === 0) {
        alert("Please provide user details and select at least one coverage.");
        return;
    }

    const response = await fetch("http://localhost:5000/api/calculatePremium", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userDetails, selectedCoverages }),
    });

    const premiumData = await response.json();
    displayPremium(premiumData.premiumResponse);
});

// Display Premium
function displayPremium(premiumData) {
  const premiumDetails = document.getElementById('premiumDetails');
  const lines = premiumData.split('\n').filter(line => line.trim() !== '');
  
  let htmlContent = '';
  let currentSection = '';
  
  for (let line of lines) {
      if (line.includes('Premium Calculation') || line.includes('Breakdown')) {
          currentSection = `<h3>${line}</h3>`;
          htmlContent += currentSection;
      } else if (line.includes(':')) {
          const [title, value] = line.split(':');
          htmlContent += `<p><strong>${title.trim()}:</strong> ${value.trim()}</p>`;
      } else {
          htmlContent += `<p>${line.trim()}</p>`;
      }
  }

  premiumDetails.innerHTML = htmlContent;
  premiumSection.classList.remove('hidden');
}

