const express = require('express');
const cors = require('cors');
const axios = require('axios');

const app = express();
app.use(cors());
app.use(express.json());

const OPENAI_API_KEY = 'YOUR_OPENAI';

// Helper function to call OpenAI API for coverages
async function fetchCoveragesFromOpenAI(prompt) {
    try {
        const response = await axios.post(
            'https://api.openai.com/v1/chat/completions',
            {
                model: "gpt-3.5-turbo",
                messages: [
                    { role: "system", content: "You are an expert in insurance coverage suggestions." },
                    { role: "user", content: prompt }
                ],
                max_tokens: 300,
                temperature: 0.7,
            },
            {
                headers: {
                    'Authorization': `Bearer ${OPENAI_API_KEY}`,
                    'Content-Type': 'application/json',
                },
            }
        );

        const content = response.data?.choices?.[0]?.message?.content;
        if (!content) throw new Error("Unexpected API response structure: 'content' is undefined.");

        const coverages = [];
        const lines = content.split('\n');
        for (const line of lines) {
            const colonIndex = line.indexOf(':');
            if (colonIndex !== -1) {
                const title = line.substring(0, colonIndex).trim();
                const description = line.substring(colonIndex + 1).trim();
                coverages.push({ title, description });
            }
        }
        return coverages;
    } catch (error) {
        console.error("Error calling OpenAI API:", error.response?.data || error.message);
        return [];
    }
}

// API to return coverage data
app.post('/api/getCoverage', async (req, res) => {
    const { occupation, industry } = req.body;
    let prompt;

    if (occupation) {
        prompt = `Suggest appropriate insurance coverages for a person working as ${occupation}. Include title and description separated by ':'`;
    } else if (industry) {
        prompt = `Suggest appropriate insurance coverages for a company in the ${industry} industry. Include title and description separated by ':'`;
    } else {
        return res.status(400).json({ error: 'Invalid input. Please provide occupation or industry.' });
    }

    const coverages = await fetchCoveragesFromOpenAI(prompt);
    res.json(coverages);
});

// Helper function to call OpenAI API for premium calculation
async function fetchPremiumFromOpenAI(prompt) {
    try {
        const response = await axios.post(
            'https://api.openai.com/v1/chat/completions',
            {
                model: "gpt-3.5-turbo",
                messages: [{ role: "user", content: prompt }],
                max_tokens: 300,
                temperature: 0.7,
            },
            {
                headers: {
                    'Authorization': `Bearer ${OPENAI_API_KEY}`,
                    'Content-Type': 'application/json',
                },
            }
        );

        const content = response.data.choices[0]?.message?.content.trim();
        return content || "No response received from OpenAI.";
    } catch (error) {
        console.error("Error calling OpenAI API for premium:", error.response?.data || error.message);
        return "Error calculating premium. Please try again later.";
    }
}

// API to calculate premium
app.post('/api/calculatePremium', async (req, res) => {
    const { userDetails, selectedCoverages } = req.body;

    if (!userDetails || !selectedCoverages || selectedCoverages.length === 0) {
        return res.status(400).json({ error: "Missing user details or selected coverages." });
    }

    const prompt = `
    Calculate a premium amount for the following user data:
    User Details:
    ${Object.entries(userDetails).map(([key, value]) => `${key}: ${value}`).join('\n')}

    Selected Coverages:
    ${selectedCoverages.join(', ')}

    Provide a breakdown of monthly, quarterly, and yearly premiums. No need to explain the calculation, just return premiums. Apply a 2% and 5% discount on quarterly and yearly premiums respectively.
    `;

    const premiumResponse = await fetchPremiumFromOpenAI(prompt);
    console.log("Premium Response:", premiumResponse);
    res.json({ premiumResponse });
});

// Start server
const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
